document.addEventListener("DOMContentLoaded", function () {
  const wilaya = document.getElementById("wilaya");
  for (let i = 1; i <= 58; i++) {
    const opt = document.createElement("option");
    opt.value = opt.textContent = "ولاية " + i;
    wilaya.appendChild(opt);
  }

  const form = document.getElementById("orderForm");
  form.addEventListener("submit", function () {
    document.getElementById("confirmation").style.display = "block";
  });
});
